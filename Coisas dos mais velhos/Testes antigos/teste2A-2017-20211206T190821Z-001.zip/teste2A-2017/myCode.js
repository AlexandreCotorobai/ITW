﻿var userNumber = document.getElementById("userNumber");
var userNumberError = document.getElementById("userNumber_Error")

var userName = document.getElementById("userName");
var userNameError = document.getElementById("userName_Error");

var cur11 = document.getElementById("cur1_1").value;
var cur12 = document.getElementById("cur1_2").value;
var cur13 = document.getElementById("cur1_3").value;
var cur14 = document.getElementById("cur1_4").value;
var cur15 = document.getElementById("cur1_5").value;
var cur1Error = document.getElementById("cur1_M_Error");

var cur21 = document.getElementById("cur2_1").value;
var cur22 = document.getElementById("cur2_2").value;
var cur23 = document.getElementById("cur2_3").value;
var cur24 = document.getElementById("cur2_4").value;
var cur25 = document.getElementById("cur2_5").value;
var cur2Error = document.getElementById("cur2_M_Error");

function validateForm() {
    var retVal = true;
    if (userNumber.value > 10000) {
        if (userNumberError.classList.contains("hide"))
            userNumberError.classList.remove("hide");
            userNumberError.classList.add("no_hide");
            retVal = false;
    }


    if (userName.value.trim().length < 15) {
        if (userNameError.classList.contains("hide"))
            userNameError.classList.remove("hide");
            userNameError.classList.add("no_hide");
            retVal = false;
    }
    

    if (cur11.trim().length=0) {
        if (cur1Error.classList.contains("hide"))
            cur1Error.classList.remove("hide");
            cur1Error.classList.add("no_hide");

            retVal = false;
    }
    if (cur12.trim().length = 0) {
        if (cur1Error.classList.contains("hide"))
            cur1Error.classList.remove("hide");
            cur1Error.classList.add("no_hide");

            retVal = false;

    }
    if (cur13.trim().length = 0) {
        if (cur1Error.classList.contains("hide"))
            cur1Error.classList.remove("hide");
        cur1Error.classList.add("no_hide");

        retVal = false;

    }
    if (cur14.trim().length = 0) {
        if (cur1Error.classList.contains("hide"))
            cur1Error.classList.remove("hide");
        cur1Error.classList.add("no_hide");

        retVal = false;

    }
    if (cur15.trim().length = 0) {
        if (cur1Error.classList.contains("hide"))
            cur1Error.classList.remove("hide");
        cur1Error.classList.add("no_hide");

        retVal = false;

    }
    if (cur21.trim().length = 0) {
        if (cur2Error.classList.contains("hide"))
            cur2Error.classList.remove("hide");
        cur2Error.classList.add("no_hide");

        retVal = false;
    }
    if (cur22.trim().length = 0) {
        if (cur2Error.classList.contains("hide"))
            cur2Error.classList.remove("hide");
        cur2Error.classList.add("no_hide");

        retVal = false;

    }
    if (cur23.trim().length = 0) {
        if (cur2Error.classList.contains("hide"))
            cur2Error.classList.remove("hide");
        cur2Error.classList.add("no_hide");

        retVal = false;

    }
    if (cur24.trim().length = 0) {
        if (cur2Error.classList.contains("hide"))
            cur2Error.classList.remove("hide");
        cur2Error.classList.add("no_hide");

        retVal = false;

    }
    if (cur25.trim().length = 0) {
        if (cur2Error.classList.contains("hide"))
            cur2Error.classList.remove("hide");
        cur2Error.classList.add("no_hide");

        retVal = false;
    }

    return retVal;
}

function clearErrorMessages() {
    if (userNameError.classList.contains("no_hide"))
        userNameError.classList.remove("no_hide");
        userNameError.classList.add("hide");
    if (userNameError.classList.contains("hide"))
        userNameError.classList.add("hide");


    if (userNumberError.classList.contains("no_hide"))
        userNumberError.classList.remove("no_hide");
        userNumberError.classList.add("hide");
    if (userNumberError.classList.contains("hide"))
        userNumberError.classList.add("hide");


    if (cur1Error.classList.contains("no_hide"))
        cur1Error.classList.remove("no_hide");
        cur1Error.classList.add("hide");
    if (cur1Error.classList.contains("hide"))
        cur1Error.classList.add("hide");

    if (cur2Error.classList.contains("no_hide"))
        cur2Error.classList.remove("no_hide");
        cur2Error.classList.add("hide");
    if (cur2Error.classList.contains("hide"))
        cur2Error.classList.add("hide");


}